package multithreading;

public class ConcurrencyPractice {
	public static void main(String[] args) {
		Object lock = new Object();

		Thread countUp = new Thread(new CountUp(lock));
		Thread countdown = new Thread(new Countdown(lock));

		countdown.start();
		countUp.start();
	}
}
