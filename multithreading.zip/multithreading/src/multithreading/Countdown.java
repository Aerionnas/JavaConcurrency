package multithreading;

public class Countdown implements Runnable {

	private final Object lock;

	public Countdown(Object lock) {
		this.lock = lock;
	}

	@Override
	public void run() {
		synchronized (lock) {
			try {
				lock.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			for (int i = 19; i >= 0; i--) {
				System.out.println(i);
				try {
					Thread.sleep(1000);

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
