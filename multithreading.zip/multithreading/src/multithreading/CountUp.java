package multithreading;

public class CountUp implements Runnable {

	private final Object lock;

	public CountUp(Object lock) {
		this.lock = lock;
	}

	@Override
	public void run() {
		synchronized (lock) {
			for (int i = 0; i < 21; i++) {
				System.out.println(i);
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			lock.notify();
		}

	}
}
